Programming Language: Java
Compiler: javac
Interpreter: java
Class Description:

Main Class Usually starts with Problem Name
BaseSolution: Kind of Utility Class and provides common functions for I/O
