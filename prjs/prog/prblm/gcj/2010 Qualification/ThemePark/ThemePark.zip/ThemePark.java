import java.math.BigInteger;
import java.util.StringTokenizer;
public class ThemePark extends BaseSolution {
	public static void main(String args[]) throws Exception{
		new ThemePark().start(args[0]);
	}
	public String solveTestCase() throws Exception{
		StringTokenizer st = new StringTokenizer(readLine());
		long R = Long.parseLong(st.nextToken());
		long k = Long.parseLong(st.nextToken());
		int N = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(readLine());
		long groups[] = new long[N];
		for(int i=0;i<N;i++){
			groups[i] = Long.parseLong(st.nextToken());
		}
		BigInteger totalRevenue = new BigInteger("0");
		long maxPerRound = k;
		int cGroup = 0;
		long moneyThisRound = 0;
		boolean full = false;
		for(long r=0;r<R;r++){
		  	// for each round
		  moneyThisRound = 0;
		  full = false;
		  int counter = 0;
                  while(!full){
                    if((moneyThisRound+groups[cGroup%N])<=maxPerRound&&counter<N){
			    //if we can accomodate
			    moneyThisRound+=groups[cGroup%N];
			    cGroup = (cGroup+1)%N;
		    }
		    else {
			    full = true;
		    }
		    counter++;
		  }

		  totalRevenue = totalRevenue.add(new BigInteger(moneyThisRound+""));
	            
		}
		return totalRevenue.toString();
	}
}
